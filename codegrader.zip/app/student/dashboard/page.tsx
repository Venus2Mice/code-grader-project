"use client"

import { useState } from "react"
import Link from "next/link"
import { Plus, BookOpen, CheckCircle, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { mockClasses } from "@/lib/mock-data"
import { JoinClassDialog } from "@/components/join-class-dialog"
import { Navbar } from "@/components/navbar"

export default function StudentDashboard() {
  const [enrolledClasses, setEnrolledClasses] = useState(mockClasses)
  const [isJoinDialogOpen, setIsJoinDialogOpen] = useState(false)

  const handleJoinClass = (classCode: string) => {
    console.log("[v0] Joining class with code:", classCode)
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-40 right-10 w-24 h-24 border-4 border-border bg-accent rotate-12" />
      <div className="absolute bottom-20 left-10 w-32 h-32 border-4 border-border bg-secondary rounded-full" />

      <Navbar />

      <div className="border-b-4 border-border bg-secondary">
        <div className="mx-auto max-w-7xl px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-black uppercase text-secondary-foreground">My Classes</h1>
              <p className="mt-2 text-base font-bold text-secondary-foreground/80">View your enrolled courses</p>
            </div>
            <Button onClick={() => setIsJoinDialogOpen(true)} className="gap-2">
              <Plus className="h-5 w-5" />
              Join Class
            </Button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-12 relative z-10">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {enrolledClasses.map((classItem) => (
            <Link key={classItem.id} href={`/student/class/${classItem.id}`}>
              <Card className="group cursor-pointer p-6 transition-all hover:translate-x-1 hover:translate-y-1 hover:shadow-none">
                <div className="mb-6 flex items-start justify-between">
                  <div className="flex h-14 w-14 items-center justify-center border-4 border-border bg-primary">
                    <BookOpen className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <span className="border-4 border-border bg-muted px-3 py-1 text-xs font-black uppercase">
                    {classItem.code}
                  </span>
                </div>

                <h3 className="mb-3 text-2xl font-black uppercase group-hover:text-primary">{classItem.name}</h3>

                <p className="mb-6 line-clamp-2 text-sm font-bold text-muted-foreground">{classItem.description}</p>

                <div className="flex items-center gap-4 text-sm font-bold">
                  <div className="flex items-center gap-1 text-green-600 dark:text-green-400">
                    <CheckCircle className="h-5 w-5" />
                    <span>3 Done</span>
                  </div>
                  <div className="flex items-center gap-1 text-yellow-600 dark:text-yellow-400">
                    <Clock className="h-5 w-5" />
                    <span>2 Todo</span>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>

        {enrolledClasses.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 border-4 border-border bg-card">
            <BookOpen className="mb-6 h-20 w-20" />
            <h3 className="mb-3 text-2xl font-black uppercase">No Classes Yet</h3>
            <p className="mb-8 font-bold text-muted-foreground">Join your first class to get started</p>
            <Button onClick={() => setIsJoinDialogOpen(true)} className="gap-2">
              <Plus className="h-5 w-5" />
              Join Class
            </Button>
          </div>
        )}
      </div>

      <JoinClassDialog open={isJoinDialogOpen} onOpenChange={setIsJoinDialogOpen} onJoinClass={handleJoinClass} />
    </div>
  )
}
