"use client"

import { useState } from "react"
import Link from "next/link"
import { Plus, Users, BookOpen, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { mockClasses } from "@/lib/mock-data"
import { CreateClassDialog } from "@/components/create-class-dialog"
import { Navbar } from "@/components/navbar"

export default function TeacherDashboard() {
  const [classes, setClasses] = useState(mockClasses)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)

  const handleCreateClass = (newClass: any) => {
    setClasses([
      ...classes,
      {
        ...newClass,
        id: String(classes.length + 1),
        teacherId: "teacher1",
        createdAt: new Date(),
        studentCount: 0,
      },
    ])
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="border-b-4 border-border bg-secondary">
        <div className="mx-auto max-w-7xl px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-black uppercase text-secondary-foreground">My Classes</h1>
              <p className="mt-2 font-bold text-secondary-foreground/80">Manage your courses and assignments</p>
            </div>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2">
              <Plus className="h-5 w-5" />
              Create Class
            </Button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {classes.map((classItem) => (
            <Link key={classItem.id} href={`/teacher/class/${classItem.id}`}>
              <Card className="group cursor-pointer p-6 transition-all hover:translate-x-1 hover:translate-y-1 hover:shadow-none shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] dark:shadow-[6px_6px_0px_0px_rgba(255,255,255,1)]">
                <div className="mb-6 flex items-start justify-between">
                  <div className="flex h-14 w-14 items-center justify-center bg-primary border-4 border-border">
                    <BookOpen className="h-7 w-7 text-primary-foreground" />
                  </div>
                  <span className="border-4 border-border bg-muted px-4 py-2 text-xs font-black uppercase">
                    {classItem.code}
                  </span>
                </div>

                <h3 className="mb-3 text-2xl font-black uppercase group-hover:text-primary">{classItem.name}</h3>

                <p className="mb-6 line-clamp-2 font-medium">{classItem.description}</p>

                <div className="flex items-center gap-6 font-bold text-sm">
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    <span>{classItem.studentCount} students</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    <span>{classItem.createdAt.toLocaleDateString()}</span>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>

        {classes.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 border-4 border-border bg-card">
            <BookOpen className="mb-6 h-20 w-20" />
            <h3 className="mb-3 text-2xl font-black uppercase">No classes yet</h3>
            <p className="mb-8 font-bold">Create your first class to get started</p>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2">
              <Plus className="h-5 w-5" />
              Create Class
            </Button>
          </div>
        )}
      </div>

      <CreateClassDialog
        open={isCreateDialogOpen}
        onOpenChange={setIsCreateDialogOpen}
        onCreateClass={handleCreateClass}
      />
    </div>
  )
}
